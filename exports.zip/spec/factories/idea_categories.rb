FactoryBot.define do
  factory :idea_category do
    name { 'アプリ' }
    body { '楽しいアプリ' }
  end
end